# Mentat husky de Kleshmersh / Kleshmersh husky mentat

Ajout graphique local du 15 octobre 2026, préparé à la demande de Tornie.
Le conseiller est un husky anthropomorphe au pelage noir et orange cuivré,
aux yeux bleus, en tenue du désert. Le portrait remplace Chani uniquement pour
Kleshmersh dans Vanilla, Tornie et Jericho. Les éditions Lite ne proposent pas
cette faction. Aucune publication ni nouvelle version n'est créée ici.

Local artwork addition, 15 October 2026, requested by Tornie. A black and copper
orange anthropomorphic husky with blue eyes and desert clothing replaces Chani
only for Kleshmersh in Vanilla, Tornie and Jericho. Lite editions do not offer
Kleshmersh. This change does not publish a release.

## Fichiers / Files

| PNG | Dimensions | Usage |
| --- | --- | --- |
| `MentatHusky_Kleshmersh.png` | 640 × 400 | Fond à la taille de l’interface / full-size UI background |
| `MentatHusky_Kleshmersh_Eyes.png` | 630 × 34 | 5 cases horizontales de 126 × 34 / five horizontal eye cells |
| `MentatHusky_Kleshmersh_Mouth.png` | 500 × 46 | 5 cases horizontales de 100 × 46 / five horizontal mouth cells |

Yeux : face, gauche, droite, bas, fermés. Bouche : fermée, entrouverte, ouverte,
arrondie, fermée. Les coordonnées UI sont (66,158) pour les yeux et (78,252)
pour la bouche ; les planches sont déjà à la taille UI (`Double = false`).
L'espace entre les yeux est transparent afin de conserver l'arête du museau.
Le portrait et ses overlays sont RGBA, sans index de transparence de palette.

Eyes: forward, left, right, down, closed. Mouth: closed, slightly open, open,
rounded, closed. UI anchors are (66,158) and (78,252), with the strips already exported at UI size. The transparent gap between the eye patches preserves the nose bridge.
PNG assets use RGBA instead of a palette transparency key. The background and strips
are already at UI size, so `Double = false` bypasses the legacy ScaleHD/Scale2x
doubling routine that requires an indexed palette.

Les ressources sont présentes dans `data/`, `mods/Tornie/data/` et
`mods/Jericho/data/`. `[Mentat 10]` cible l'identité Kleshmersh dans les deux mods
complets ; Jericho conserve son adaptation entre identité et emplacement.
Le moteur attribue le même portrait à Kleshmersh en Vanilla.

The resources live in `data/`, `mods/Tornie/data/` and `mods/Jericho/data/`.
The two full mods use `[Mentat 10]`, preserving Jericho's runtime identity mapping.
Vanilla resolves Kleshmersh to the same portrait through ModManager.

## Origine / Provenance

Le personnage et les expressions ont été créés avec l'outil imagegen intégré,
selon la demande de Tornie. Les exports, les planches et le GIF sont assemblés
avec ImageMagick. Le cadre du briefing provient du fond Chani déjà présent dans
le projet et conserve son attribution existante. Les originaux Chani ne sont pas
modifiés. Les fichiers réutilisent les minutages et interactions du jeu ; aucune
voix n'est ajoutée.

Character artwork and expressions were generated with built-in imagegen from
Tornie's brief. ImageMagick exports the native PNGs, strips and GIF. The briefing
frame derives from the project's existing Chani background and retains its
existing attribution. Chani's original files are unchanged. Existing game timing
and mouse interactions drive the animations; no voice recording is added.

## Vérification / Validation

`--verify-mods` vérifie le chargement des cinq états, capture le véritable écran
de briefing de Kleshmersh dans les trois modes, vérifie l'ancrage du museau et
le démarrage de la bouche pendant le texte. Le contrôle des ressources vérifie
les nouvelles sommes SHA-256. La documentation web FR/EN est préparée en patch
depuis la branche `gh-pages` actuelle (1.0.540), séparément de ce checkout
1.0.538 ; les téléchargements publics existants restent identifiés 1.0.540.

`--verify-mods` checks five decoded states, captures Kleshmersh's actual briefing
in all three modes, verifies the stable nose and speech start. Bundled-content
validation checks the new SHA-256 entries. The FR/EN website update is prepared
as a patch against current `gh-pages` (1.0.540), separately from this 1.0.538
checkout; existing public downloads retain their 1.0.540 identity.

Validation finale : 122 cas de test / 7 412 assertions réussis ; vérification
intégrée terminée avec 1 210 scénarios chargés. Les captures du véritable
briefing Kleshmersh valident les cinq états dans Vanilla, Tornie et Jericho.

Final validation: 122 test cases / 7,412 assertions passed; the full runtime
smoke completed with 1,210 scenarios loaded. Actual Kleshmersh briefing captures
validate all five states in Vanilla, Tornie and Jericho.
